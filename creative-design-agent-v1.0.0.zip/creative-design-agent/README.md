# 创意与设计 Agent

给 Codex 的中文创意搭档，用于品牌和营销文案、视觉方向提案及跨媒介制作。它把需求澄清、方案选择、专项制作和成品验收串在一起。

- 改一句标题或一段文案时，直接修改并核对事实与语气。
- 简单创作可以一次交付几版可用成品。选中且验收通过的一版即可交付。
- 复杂项目先确定受众、用途和交付形式，用草图、分镜或代表性样稿比较方向，选定后再展开制作。

## 包内组件

| 组件 | 位置 | 作用 |
| --- | --- | --- |
| 原生 Agent 角色 | `agents/creative-design.toml` | 让主会话可以显式委派创意任务，继承父任务的模型与权限 |
| 配套 Skill 1.0.0 | `skills/creative-design/` | 定义工作流程，包含提案与文案、能力选择、按媒介验收三份参考文件 |
| 能力盘点脚本 | `skills/creative-design/scripts/inventory_skills.py` | 只读扫描已安装的 Skills，列出名称、路径、版本及调用限制 |

## 安装

下载并解压本包。在用户主目录下将 `skills/creative-design/` 整个文件夹复制到 `~/.agents/skills/creative-design/`，将 `agents/creative-design.toml` 复制到 `~/.codex/agents/`。如果自定义了 `CODEX_HOME`，将角色文件放在该目录下的 `agents/`。遇到已安装的同名文件时，先比较版本并保留自己的修改。

打开一个新 Codex 会话，输入 `$creative-design` 调用 Skill，或明确要求主会话“调用 creative-design 子智能体”。原生角色需要宿主支持自定义子智能体。

可以这样试用：

> 调用 creative-design。给一场面向新手的品牌摄影工作坊写两版招募标题。一个方向强调消除紧张感，一个方向强调上手就能拍。每版附一句副标题。

检查包内自带的清单工具时，从解压后的项目根目录运行以下命令（Python 3.10+）。

```sh
python skills/creative-design/scripts/inventory_skills.py --root skills
```

输出应有一个名为 `creative-design` 的条目，且其 `errors` 为空。图片生成、PPT 和视频制作等专项能力由实际环境按需提供。

## 来源与依赖

本包收录自行定义和开发的 Agent 角色、创意工作流程与能力盘点脚本。能力盘点脚本使用捆绑的 PyYAML 6.0.3，原作者署名和 MIT 许可证见 [依赖许可证](skills/creative-design/scripts/_vendor/pyyaml-6.0.3.dist-info/licenses/LICENSE)。发布版把 Agent 入口改为当前用户的主目录，使其可跨账号安装。

配套的第三方设计与文案工具由各自的上游维护，可独立安装。
