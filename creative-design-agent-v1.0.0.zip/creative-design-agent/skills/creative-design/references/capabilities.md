# 能力发现与选择

## 读取方式
会话提供的 Skills 清单是起点，可能被截断。首次完整选型、用户新增技能或发现清单过时时，用 Python 执行 scripts/inventory_skills.py；不扫描整盘，不运行候选技能里的脚本来“发现”它。
默认检查用户 ~/.agents/skills、有效 CODEX_HOME/skills；--project <当前项目> 仅检查当前目录及祖先中的 .agents/skills、.codex/skills，到 Git 根停止。--root 可指定隔离目录，替代默认范围；插件目录只有在宿主清单明确指出且需要时才用 --root 补充。
示例：python <本Skill>/scripts/inventory_skills.py --project <项目绝对路径> --output <项目内清单.json>。
使用现有 Python 3.10+；若 PATH 没有 Python，可用本机 Codex bundled Python。本包 scripts/_vendor 含 PyYAML 6.0.3 及许可证，无需临时 pip 安装。
清单脚本只读技能目录，仅写显式 --output 文件；它不证明宿主加载，不猜运行依赖，不选择创意方向。

## 记录与冲突
清单含 name、description、路径、入口/包哈希、可获得的版本与来源、两种调用政策、资源/脚本数量与解析错误。来源记录是待核验元数据，不当成授权。
状态分列：已安装 / 宿主可发现 / 依赖就绪 / 基础检查 / 实际任务。脚本无法证明的均 unknown；宿主主动给出入口可作为可发现证据，实际脚本成功仅覆盖被执行检查。
重复名称保留所有位置及 hash，核实是否同源、有用户修改与有效作用域；不自动合并或删除。策略未知先读取文件解决；隐式禁用保留原约束。
仅对相关候选读取 SKILL.md 与所需资源。按真实目标选择，关键词匹配只是初筛，不是资格证明。新技能可以补足/替代候选，但不自动改变当前任务方向。

## 初始候选提示（不是白名单）
- 前端主执行：frontend-design / design-taste-frontend / impeccable，选一个适合任务的主要能力；后者的引擎/命令按实际环境检查。
- 交互依据：ui-ux-pro-max；配色/排版：better-colors / better-typography；局部比较 variant 需明确调用。
- 品牌已有规范：brand-to-design-md；品牌视觉图：brandkit 配合可用 imagegen。品牌图不冒充可编辑矢量或完整品牌策略。
- 网页演示：frontend-slides / guizang-ppt-skill；可编辑 PPTX：ppt-design-skill 或宿主 Presentations，先确认依赖与格式。
- 动效：motion-design；视频：remotion-best-practices 配合真实项目/渲染环境。不预装大型视频环境。
- 前端审查：web-design-guidelines；React/Next.js 性能：vercel-react-best-practices，仅在相关任务使用。
- 文案：copywriting / copy-editing；创意提报由本规范负责，专门策略/长脚本能力未实测时说清。
- 实际制作/读取/验收还可使用宿主 imagegen、Sites、Presentations、Documents、PDF、图表和浏览器能力。仅按当前请求触发。

工具已装不代表依赖齐全。使用前核对实际运行要求；无法满足时提供选择，不静默替换 PPTX 为 HTML、视频为分镜。

