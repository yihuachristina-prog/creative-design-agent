"""Read-only local Skill inventory. Never executes skill code or changes installations."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).parent / "_vendor"))
try:
    import yaml
except ImportError:
    raise SystemExit("Missing bundled PyYAML; restore scripts/_vendor from this Skill package.")

SKIP = {"node_modules", ".git", "__pycache__", "_vendor", ".venv"}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_yaml(path, frontmatter=False):
    raw = path.read_text(encoding="utf-8-sig")
    if frontmatter:
        lines = raw.splitlines()
        if not lines or lines[0].strip() != "---":
            raise ValueError("missing YAML frontmatter")
        end = next((i for i in range(1, len(lines)) if lines[i].strip() == "---"), None)
        if end is None:
            raise ValueError("unclosed YAML frontmatter")
        raw = "\n".join(lines[1:end])
    data = yaml.safe_load(raw)
    if not isinstance(data, dict):
        raise ValueError("metadata must be a mapping")
    return data

def default_roots(project=None):
    home = Path.home()
    roots = [home / ".agents/skills", Path(os.environ.get("CODEX_HOME", str(home / ".codex"))) / "skills"]
    if project:
        p = Path(project).resolve()
        for ancestor in [p, *p.parents]:
            roots += [ancestor / ".agents/skills", ancestor / ".codex/skills"]
            if (ancestor / ".git").exists():
                break
    return roots

def entries(root):
    """Follow directory links but prevent cycles and do not recurse inside a skill."""
    pending, seen = [root], set()
    while pending:
        p = pending.pop()
        resolved = p.resolve()
        key = str(resolved).casefold() if os.name == "nt" else str(resolved)
        if key in seen:
            continue
        seen.add(key)
        if (p / "SKILL.md").is_file():
            yield p / "SKILL.md"
            continue
        for child in sorted(p.iterdir(), key=lambda v: v.name):
            if child.is_dir() and child.name not in SKIP:
                pending.append(child)

def inspect(entry):
    row = {"path": str(entry.resolve()), "name": None, "description": None,
           "errors": [], "installed": True, "host_discoverable": "unknown",
           "dependencies_ready": "unknown", "basic_check": "unknown", "task_verified": "unknown",
           "implicit_invocation": "unknown", "version": None, "source": None}
    try:
        row["entry_sha256"] = digest(entry)
        data = read_yaml(entry, True)
        for field in ("name", "description"):
            value = data.get(field)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field} must be a nonempty string")
            row[field] = value
        metadata = data.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValueError("metadata must be a mapping")
        row["version"] = metadata.get("version", data.get("version"))
        row["declared_dependencies"] = data.get("dependencies")
        disabled = data.get("disable-model-invocation", False)
        if not isinstance(disabled, bool):
            raise ValueError("disable-model-invocation must be boolean")
        implicit = not disabled
        ui = entry.parent / "agents/openai.yaml"
        if ui.is_file():
            u = read_yaml(ui)
            policy = u.get("policy", {})
            if not isinstance(policy, dict):
                raise ValueError("policy must be a mapping")
            allow = policy.get("allow_implicit_invocation", True)
            if not isinstance(allow, bool):
                raise ValueError("allow_implicit_invocation must be boolean")
            implicit = implicit and allow
            row["declared_tool_dependencies"] = u.get("dependencies")
        row["implicit_invocation"] = implicit
        row["metadata_valid"] = True
    except (OSError, ValueError, yaml.YAMLError) as exc:
        row["metadata_valid"] = False
        row["errors"].append(str(exc))
    manifest = entry.parent / "codex-installation.json"
    if manifest.is_file():
        try:
            row["source"] = json.loads(manifest.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            row["errors"].append("source record: " + str(exc))
    counts, hashes = {}, []
    try:
        for base, dirs, files in os.walk(entry.parent, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in SKIP)
            for filename in sorted(files):
                p = Path(base) / filename
                if p.is_symlink():
                    continue
                relative = p.relative_to(entry.parent).as_posix()
                counts[p.suffix.lower() or "(none)"] = counts.get(p.suffix.lower() or "(none)", 0) + 1
                hashes.append(relative + "\0" + digest(p))
        row["content_sha256"] = hashlib.sha256("\n".join(sorted(hashes)).encode()).hexdigest()
        row["file_types"] = counts
        row["content_hash_exclusions"] = sorted(SKIP)
    except OSError as exc:
        row["errors"].append("resource scan: " + str(exc))
    return row

def collect(roots):
    rows, errors, seen_roots = [], [], set()
    for root in roots:
        root = Path(root).expanduser().resolve()
        key = os.path.normcase(str(root))
        if key in seen_roots:
            continue
        seen_roots.add(key)
        if not root.is_dir():
            errors.append({"root": str(root), "error": "directory_missing"})
            continue
        try:
            rows.extend(inspect(e) for e in entries(root))
        except OSError as exc:
            errors.append({"root": str(root), "error": str(exc)})
    by_path = {r["path"]: r for r in rows}
    rows = sorted(by_path.values(), key=lambda r: (r["name"] or "", r["path"]))
    names = {}
    for row in rows:
        if row["name"]:
            names.setdefault(row["name"], []).append(row["path"])
    return {"schema_version": 1, "generated_at": datetime.now(timezone.utc).isoformat(),
            "scope": "filesystem inventory only; no host or runtime validation",
            "roots": sorted(seen_roots), "skills": rows, "root_errors": errors,
            "duplicate_names": {n: paths for n, paths in names.items() if len(paths) > 1}}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", action="append", help="Explicit skill root; replaces defaults, repeatable")
    parser.add_argument("--project", help="Include project/ancestor skill roots; ignored with explicit --root")
    parser.add_argument("--output", help="Write JSON here instead of stdout")
    args = parser.parse_args()
    result = collect(args.root if args.root else default_roots(args.project))
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        target = Path(args.output).resolve()
        roots = [Path(r).resolve() for r in result["roots"]]
        if any(target == root or root in target.parents for root in roots):
            raise SystemExit("--output must be outside inspected skill roots")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)
if __name__ == "__main__":
    main()

